﻿//------------------------------------------------------------------------------
// <copyright file="MainWindow.xaml.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------

namespace Microsoft.Samples.Kinect.BackgroundRemovalBasics
{
    using System;
    using System.Globalization;
    using System.IO;
    using System.Windows;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using Microsoft.Kinect;
    using Microsoft.Kinect.Toolkit;
    using Microsoft.Kinect.Toolkit.BackgroundRemoval;
   // using Microsoft.Speech.AudioFormat;
  //  using Microsoft.Speech.Recognition;

    using LightBuzz.Vitruvius;


    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IDisposable
    {
        /// <summary>
        /// Format we will use for the depth stream
        /// </summary>
        private const DepthImageFormat DepthFormat = DepthImageFormat.Resolution320x240Fps30;

        /// <summary>
        /// Format we will use for the color stream
        /// </summary>
        private const ColorImageFormat ColorFormat = ColorImageFormat.RgbResolution640x480Fps30;

        /// <summary>
        /// Bitmap that will hold color information
        /// </summary>
        private WriteableBitmap foregroundBitmap;

        /// <summary>
        /// Active Kinect sensor
        /// </summary>
        private KinectSensorChooser sensorChooser;

        /// <summary>
        /// Our core library which does background 
        /// </summary>
        private BackgroundRemovedColorStream backgroundRemovedColorStream;

        /// <summary>
        /// Intermediate storage for the skeleton data received from the sensor
        /// </summary>
        private Skeleton[] skeletons;

        /// <summary>
        /// the skeleton that is currently tracked by the app
        /// </summary>
        private int currentlyTrackedSkeletonId;

        /// <summary>
        /// Track whether Dispose has been called
        /// </summary>
        /// 
        private bool setup = true;

        public bool Setup3
        {
            get { return setup; }
            set { setup = value; }
        }

        private bool disposed;

        private string[] file = new string[10];


        private int num = 0;//显示框编号
        private int pnum = 0;//图片编号
        private int LocX = 60;  //图片初始参考位置
        private int LocY = 550;
        private int NLocX = 50;
        private int NLocY = 540;
        private int WIDTH = 160;
        private int HEIGHT = 160;
        private int Nwidth = 190;
        private int Nheigth = 190;
        private int dw = 220;
        private string path = "/BackgroundRemovalBasics-WPF;component/Images/";


        GestureController _gestureController;


        /// <summary>
        /// Initializes a new instance of the MainWindow class.
        /// </summary>
        public MainWindow()
        {
            this.InitializeComponent();

            // initialize the sensor chooser and UI
            this.sensorChooser = new KinectSensorChooser();
            this.sensorChooserUi.KinectSensorChooser = this.sensorChooser;
            this.sensorChooser.KinectChanged += this.SensorChooserOnKinectChanged;
            this.sensorChooser.Start();
            file[0] = "Background1.jpg";
            file[1] = "Background2.jpg";
            file[2] = "Background3.jpg";
            file[3] = "Background4.jpg";
            file[4] = "Background5.jpg";
            file[5] = "Background6.jpg";
            file[6] = "Background7.jpg";
            file[7] = "Background8.jpg";
            file[8] = "Background9.jpg";
            file[9] = "Background10.jpg";
            Uri back = new Uri(path + file[0], UriKind.Relative);
            BitmapImage backmap = new BitmapImage(back);
            Backdrop.Source = backmap;
            image1.Width = Nwidth;
            image1.Height = Nheigth;
            image1.Margin = new Thickness(NLocX, NLocY, 0, 0);

            _gestureController = new GestureController(GestureType.All);
            _gestureController.GestureRecognized += GestureController_GestureRecognized;



        }

        /// <summary>
        /// Finalizes an instance of the MainWindow class.
        /// This destructor will run only if the Dispose method does not get called.
        /// </summary>
        ~MainWindow()
        {
            this.Dispose(false);
        }

        /// <summary>
        /// Dispose the allocated frame buffers and reconstruction.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);

            // This object will be cleaned up by the Dispose method.
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Frees all memory associated with the FusionImageFrame.
        /// </summary>
        /// <param name="disposing">Whether the function was called from Dispose.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (null != this.backgroundRemovedColorStream)
                {
                    this.backgroundRemovedColorStream.Dispose();
                    this.backgroundRemovedColorStream = null;
                }

                this.disposed = true;
            }
        }

        /// <summary>
        /// Execute shutdown tasks
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void WindowClosing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            this.sensorChooser.Stop();
            this.sensorChooser = null;
            setup = false;
        }

        /// <summary>
        /// Event handler for Kinect sensor's DepthFrameReady event
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void SensorAllFramesReady(object sender, AllFramesReadyEventArgs e)
        {
            // in the middle of shutting down, or lingering events from previous sensor, do nothing here.
            if (null == this.sensorChooser || null == this.sensorChooser.Kinect || this.sensorChooser.Kinect != sender)
            {
                return;
            }

            try
            {
                using (var depthFrame = e.OpenDepthImageFrame())
                {
                    if (null != depthFrame)
                    {
                        this.backgroundRemovedColorStream.ProcessDepth(depthFrame.GetRawPixelData(), depthFrame.Timestamp);
                    }
                }

                using (var colorFrame = e.OpenColorImageFrame())
                {
                    if (null != colorFrame)
                    {
                        this.backgroundRemovedColorStream.ProcessColor(colorFrame.GetRawPixelData(), colorFrame.Timestamp);
                    }
                }

                using (var skeletonFrame = e.OpenSkeletonFrame())
                {
                    bool received = false;
                    if (received)
                    {
                        foreach (Skeleton skeleton in this.skeletons)
                        {
                            if (skeleton.TrackingState == SkeletonTrackingState.Tracked)
                            {
                                _gestureController.Update(skeleton);
                            }

                        }
                    }
                    if (null != skeletonFrame)
                    {
                        skeletonFrame.CopySkeletonDataTo(this.skeletons);
                        this.backgroundRemovedColorStream.ProcessSkeleton(this.skeletons, skeletonFrame.Timestamp);
                        received = true;
                    }
                    if (received)
                    {
                        foreach (Skeleton skeleton in this.skeletons)
                        {
                            if (skeleton.TrackingState == SkeletonTrackingState.Tracked)
                            {
                                _gestureController.Update(skeleton);
                            }

                        }
                    }

                }

                this.ChooseSkeleton();
            }
            catch (InvalidOperationException)
            {
                // Ignore the exception. 
            }
        }

        /// <summary>
        /// Handle the background removed color frame ready event. The frame obtained from the background removed
        /// color stream is in RGBA format.
        /// </summary>
        /// <param name="sender">object that sends the event</param>
        /// <param name="e">argument of the event</param>
        private void BackgroundRemovedFrameReadyHandler(object sender, BackgroundRemovedColorFrameReadyEventArgs e)
        {
            using (var backgroundRemovedFrame = e.OpenBackgroundRemovedColorFrame())
            {
                if (backgroundRemovedFrame != null)
                {
                    if (null == this.foregroundBitmap || this.foregroundBitmap.PixelWidth != backgroundRemovedFrame.Width 
                        || this.foregroundBitmap.PixelHeight != backgroundRemovedFrame.Height)
                    {
                        this.foregroundBitmap = new WriteableBitmap(backgroundRemovedFrame.Width, backgroundRemovedFrame.Height, 96.0, 96.0, PixelFormats.Bgra32, null);

                        // Set the image we display to point to the bitmap where we'll put the image data
                        this.MaskedColor.Source = this.foregroundBitmap;
                    }

                    // Write the pixel data into our bitmap
                    this.foregroundBitmap.WritePixels(
                        new Int32Rect(0, 0, this.foregroundBitmap.PixelWidth, this.foregroundBitmap.PixelHeight),
                        backgroundRemovedFrame.GetRawPixelData(),
                        this.foregroundBitmap.PixelWidth * sizeof(int),
                        0);
                }
            }
        }

        /// <summary>
        /// Use the sticky skeleton logic to choose a player that we want to set as foreground. This means if the app
        /// is tracking a player already, we keep tracking the player until it leaves the sight of the camera, 
        /// and then pick the closest player to be tracked as foreground.
        /// </summary>
        private void ChooseSkeleton()
        {
            var isTrackedSkeltonVisible = false;
            var nearestDistance = float.MaxValue;
            var nearestSkeleton = 0;

            foreach (var skel in this.skeletons)
            {
                if (null == skel)
                {
                    continue;
                }

                if (skel.TrackingState != SkeletonTrackingState.Tracked)
                {
                    continue;
                }

                if (skel.TrackingId == this.currentlyTrackedSkeletonId)
                {
                    isTrackedSkeltonVisible = true;
                    break;
                }

                if (skel.Position.Z < nearestDistance)
                {
                    nearestDistance = skel.Position.Z;
                    nearestSkeleton = skel.TrackingId;
                }
            }

            if (!isTrackedSkeltonVisible && nearestSkeleton != 0)
            {
                this.backgroundRemovedColorStream.SetTrackedPlayer(nearestSkeleton);
                this.currentlyTrackedSkeletonId = nearestSkeleton;
            }
        }

        /// <summary>
        /// Called when the KinectSensorChooser gets a new sensor
        /// </summary>
        /// <param name="sender">sender of the event</param>
        /// <param name="args">event arguments</param>
        private void SensorChooserOnKinectChanged(object sender, KinectChangedEventArgs args)
        {
            if (args.OldSensor != null)
            {
                try
                {
                    args.OldSensor.AllFramesReady -= this.SensorAllFramesReady;
                    args.OldSensor.DepthStream.Disable();
                    args.OldSensor.ColorStream.Disable();
                    args.OldSensor.SkeletonStream.Disable();

                    // Create the background removal stream to process the data and remove background, and initialize it.
                    if (null != this.backgroundRemovedColorStream)
                    {
                        this.backgroundRemovedColorStream.BackgroundRemovedFrameReady -= this.BackgroundRemovedFrameReadyHandler;
                        this.backgroundRemovedColorStream.Dispose();
                        this.backgroundRemovedColorStream = null;
                    }
                }
                catch (InvalidOperationException)
                {
                    // KinectSensor might enter an invalid state while enabling/disabling streams or stream features.
                    // E.g.: sensor might be abruptly unplugged.
                }
            }

            if (args.NewSensor != null)
            {
                try
                {
                    args.NewSensor.DepthStream.Enable(DepthFormat);
                    args.NewSensor.ColorStream.Enable(ColorFormat);
                    args.NewSensor.SkeletonStream.Enable();

                    this.backgroundRemovedColorStream = new BackgroundRemovedColorStream(args.NewSensor);
                    this.backgroundRemovedColorStream.Enable(ColorFormat, DepthFormat);

                    // Allocate space to put the depth, color, and skeleton data we'll receive
                    if (null == this.skeletons)
                    {
                        this.skeletons = new Skeleton[args.NewSensor.SkeletonStream.FrameSkeletonArrayLength];
                    }

                    // Add an event handler to be called when the background removed color frame is ready, so that we can
                    // composite the image and output to the app
                    this.backgroundRemovedColorStream.BackgroundRemovedFrameReady += this.BackgroundRemovedFrameReadyHandler;

                    // Add an event handler to be called whenever there is new depth frame data
                    args.NewSensor.AllFramesReady += this.SensorAllFramesReady;

                    try
                    {
                        args.NewSensor.DepthStream.Range = this.checkBoxNearMode.IsChecked.GetValueOrDefault()
                                                    ? DepthRange.Near
                                                    : DepthRange.Default;
                        args.NewSensor.SkeletonStream.EnableTrackingInNearRange = true;
                    }
                    catch (InvalidOperationException)
                    {
                        // Non Kinect for Windows devices do not support Near mode, so reset back to default mode.
                        args.NewSensor.DepthStream.Range = DepthRange.Default;
                        args.NewSensor.SkeletonStream.EnableTrackingInNearRange = false;
                    }

                    this.statusBarText.Text = Properties.Resources.ReadyForScreenshot;
                }
                catch (InvalidOperationException)
                {
                    // KinectSensor might enter an invalid state while enabling/disabling streams or stream features.
                    // E.g.: sensor might be abruptly unplugged.
                }
            }
        }


        /// <summary>
        /// Handles the user clicking on the screenshot button
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void ButtonScreenshotClick(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(@"C:\Users\Public\Pictures");
            if (null == this.sensorChooser || null == this.sensorChooser.Kinect)
            {
               // this.statusBarText.Text = Properties.Resources.ConnectDeviceFirst;
               
                return;
            }

            int colorWidth = this.foregroundBitmap.PixelWidth;
            int colorHeight = this.foregroundBitmap.PixelHeight;

            // create a render target that we'll render our controls to
            var renderBitmap = new RenderTargetBitmap(colorWidth, colorHeight, 96.0, 96.0, PixelFormats.Pbgra32);

            var dv = new DrawingVisual();
            using (var dc = dv.RenderOpen())
            {
                // render the backdrop
                var backdropBrush = new VisualBrush(Backdrop);
                dc.DrawRectangle(backdropBrush, null, new Rect(new Point(), new Size(colorWidth, colorHeight)));

                // render the color image masked out by players
                var colorBrush = new VisualBrush(MaskedColor);
                dc.DrawRectangle(colorBrush, null, new Rect(new Point(), new Size(colorWidth, colorHeight)));
            }

            renderBitmap.Render(dv);
    
            // create a png bitmap encoder which knows how to save a .png file
            BitmapEncoder encoder = new PngBitmapEncoder();

            // create frame from the writable bitmap and add to encoder
            encoder.Frames.Add(BitmapFrame.Create(renderBitmap));

            var time = DateTime.Now.ToString("hh'-'mm'-'ss", CultureInfo.CurrentUICulture.DateTimeFormat);

            var myPhotos = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

            var path = Path.Combine(myPhotos, "KinectSnapshot-" + time + ".png");

            // write the new file to disk
            try
            {
                using (var fs = new FileStream(path, FileMode.Create))
                {
                    encoder.Save(fs);
                }

                this.statusBarText.Text = string.Format(CultureInfo.InvariantCulture, Properties.Resources.ScreenshotWriteSuccess, path);
            }
            catch (IOException)
            {
                this.statusBarText.Text = string.Format(CultureInfo.InvariantCulture, Properties.Resources.ScreenshotWriteFailed, path);
            }
        }
        
        /// <summary>
        /// Handles the checking or unchecking of the near mode combo box
        /// </summary>
        /// <param name="sender">object sending the event</param>
        /// <param name="e">event arguments</param>
        private void CheckBoxNearModeChanged(object sender, RoutedEventArgs e)
        {
            if (null == this.sensorChooser || null == this.sensorChooser.Kinect)
            {
                return;
            }

            // will not function on non-Kinect for Windows devices
            try
            {
                this.sensorChooser.Kinect.DepthStream.Range = this.checkBoxNearMode.IsChecked.GetValueOrDefault()
                                                    ? DepthRange.Near
                                                    : DepthRange.Default;
            }
            catch (InvalidOperationException)
            {
            }
        }



        void GestureController_GestureRecognized(object sender, GestureEventArgs e)
        {
            switch (e.Type)
            {
                case GestureType.JoinedHands:
                    break;
                case GestureType.Menu:
                    break;
                case GestureType.SwipeDown:
                    break;
                case GestureType.SwipeLeft:
                    {
                       // mouse_event(MOUSEEVENT_MOVE, -10, 0, 0, 0);
                    }
                    break;
                case GestureType.SwipeRight:
                    {
                       // mouse_event(MOUSEEVENT_MOVE, 10, 0, 0, 0);
                    }
                    break;
                case GestureType.SwipeUp:
                    break;
                case GestureType.WaveLeft:
                    {
                        right(sender, e);
                     //   keybd_event((byte)Keys.PageDown, 0, KEY_DOWN, 0);
                     //   keybd_event((byte)Keys.PageDown, 0, KEY_UP, 0);

                    }
                    break;
                case GestureType.WaveRight:
                    {
                     //   keybd_event((byte)Keys.PageUp, 0, KEY_DOWN, 0);
                     //   keybd_event((byte)Keys.PageUp, 0, KEY_UP, 0);
                        left(sender, e);
                    }
                    break;
                case GestureType.ZoomIn:
                    break;
                case GestureType.ZoomOut:
                    break;
                default:
                    break;
            }
        }


        private void right(object sender, GestureEventArgs e)
        {
            Uri[] uri = new Uri[5];
            BitmapImage[] bitmap = new BitmapImage[5];

            if (num == 4)
            {
                if (pnum < 9)
                {
                    pnum++;
                    for (int i = 0; i < 5; i++)
                    {
                        uri[4 - i] = new Uri(path + file[pnum - i], UriKind.Relative);
                        bitmap[4 - i] = new BitmapImage(uri[4 - i]);

                    }
                    image1.Source = bitmap[0];
                    image2.Source = bitmap[1];
                    image3.Source = bitmap[2];
                    image4.Source = bitmap[3];
                    image5.Source = bitmap[4];
                }
                image5.Width = Nwidth;
                image5.Height = Nheigth;
                image5.Margin = new Thickness(NLocX + 4 * dw, NLocY, 0, 0);


                image4.Width = WIDTH;
                image4.Height = HEIGHT;
                image4.Margin = new Thickness(LocX + 3 * dw, LocY, 0, 0);
            }
            else
            {
                pnum++;
                num++;
                switch (num)
                {
                    case 1:
                        image1.Width = WIDTH;
                        image1.Height = HEIGHT;
                        image1.Margin = new Thickness(LocX, LocY, 0, 0);
                        image2.Width = Nwidth;
                        image2.Height = Nheigth;
                        image2.Margin = new Thickness(NLocX + dw, NLocY, 0, 0);
                        break;
                    case 2:
                        image2.Width = WIDTH;
                        image2.Height = HEIGHT;
                        image2.Margin = new Thickness(LocX + dw, LocY, 0, 0);
                        image3.Width = Nwidth;
                        image3.Height = Nheigth;
                        image3.Margin = new Thickness(NLocX + dw * 2, NLocY, 0, 0);
                        break;
                    case 3:
                        image3.Width = WIDTH;
                        image3.Height = HEIGHT;
                        image3.Margin = new Thickness(LocX + dw * 2, LocY, 0, 0);
                        image4.Width = Nwidth;
                        image4.Height = Nheigth;
                        image4.Margin = new Thickness(NLocX + dw * 3, NLocY, 0, 0);
                        break;
                    case 4:
                        image4.Width = WIDTH;
                        image4.Height = HEIGHT;
                        image4.Margin = new Thickness(LocX + dw * 3, LocY, 0, 0);
                        image5.Width = Nwidth;
                        image5.Height = Nheigth;
                        image5.Margin = new Thickness(NLocX + dw * 4, NLocY, 0, 0);
                        break;


                }
            }
            Uri back = new Uri(path + file[pnum], UriKind.Relative);
            BitmapImage backmap = new BitmapImage(back);
            Backdrop.Source = backmap;

        }

        private void left(object sender, GestureEventArgs e)
        {
            Uri[] uri = new Uri[5];
            BitmapImage[] bitmap = new BitmapImage[5];
            string path = "/BackgroundRemovalBasics-WPF;component/Images/";
            
            if (num == 0)
            {
                if (pnum  > 0)
                {
                    pnum --;
                    for(int i=0;i<5;i++)
                    {
                        uri[i] = new Uri(path + file[pnum +i], UriKind.Relative);
                        bitmap[i] = new BitmapImage(uri[i]);
                    
                    }
                    image1.Source = bitmap[0];
                    image2.Source = bitmap[1];
                    image3.Source = bitmap[2];
                    image4.Source = bitmap[3];
                    image5.Source = bitmap[4];
                }
                image1.Width=Nwidth;
                image1.Height=Nheigth;
                image1.Margin = new Thickness(NLocX,NLocY,0,0);
                

                image2.Width=WIDTH;
                image2.Height=HEIGHT;
                image2.Margin= new Thickness(LocX+dw,LocY,0,0);
            }
            else
            {
                pnum--;
                num--;
                switch(num)
                {
                    case 0:
                        image1.Width = Nwidth;
                        image1.Height = Nheigth;
                        image1.Margin = new Thickness(NLocX, NLocY, 0, 0);
                        image2.Width = WIDTH;
                        image2.Height = HEIGHT;
                        image2.Margin = new Thickness(LocX + dw , LocY, 0, 0);
                        break;
                    case 1:
                      image2.Width=Nwidth;
                      image2.Height=Nheigth;
                      image2.Margin = new Thickness(NLocX+dw,NLocY,0,0);
                      image3.Width=WIDTH;
                      image3.Height=HEIGHT;
                      image3.Margin= new Thickness(LocX+dw*2,LocY,0,0);
                      break;
                   case 2:
                      image3.Width=Nwidth;
                      image3.Height=Nheigth;
                      image3.Margin = new Thickness(NLocX+dw*2,NLocY,0,0);
                      image4.Width=WIDTH;
                      image4.Height=HEIGHT;
                      image4.Margin= new Thickness(LocX+dw*3,LocY,0,0);
                      break;
                   case 3:
                      image4.Width=Nwidth;
                      image4.Height=Nheigth;
                      image4.Margin = new Thickness(NLocX+dw*3,NLocY,0,0);
                      image5.Width=WIDTH;
                      image5.Height=HEIGHT;
                      image5.Margin= new Thickness(LocX+dw*4,LocY,0,0);
                      break;
                }
            }
            Uri back = new Uri(path + file[pnum], UriKind.Relative);
            BitmapImage  backmap = new BitmapImage(back );
            Backdrop.Source = backmap;
        }





        private void leftbtn_Click(object sender, RoutedEventArgs e)
        {
            Uri[] uri = new Uri[5];
            BitmapImage[] bitmap = new BitmapImage[5];
            string path = "/BackgroundRemovalBasics-WPF;component/Images/";
            
            if (num == 0)
            {
                if (pnum  > 0)
                {
                    pnum --;
                    for(int i=0;i<5;i++)
                    {
                        uri[i] = new Uri(path + file[pnum +i], UriKind.Relative);
                        bitmap[i] = new BitmapImage(uri[i]);
                    
                    }
                    image1.Source = bitmap[0];
                    image2.Source = bitmap[1];
                    image3.Source = bitmap[2];
                    image4.Source = bitmap[3];
                    image5.Source = bitmap[4];
                }
                image1.Width=Nwidth;
                image1.Height=Nheigth;
                image1.Margin = new Thickness(NLocX,NLocY,0,0);
                

                image2.Width=WIDTH;
                image2.Height=HEIGHT;
                image2.Margin= new Thickness(LocX+dw,LocY,0,0);
            }
            else
            {
                pnum--;
                num--;
                switch(num)
                {
                    case 0:
                        image1.Width = Nwidth;
                        image1.Height = Nheigth;
                        image1.Margin = new Thickness(NLocX, NLocY, 0, 0);
                        image2.Width = WIDTH;
                        image2.Height = HEIGHT;
                        image2.Margin = new Thickness(LocX + dw , LocY, 0, 0);
                        break;
                    case 1:
                      image2.Width=Nwidth;
                      image2.Height=Nheigth;
                      image2.Margin = new Thickness(NLocX+dw,NLocY,0,0);
                      image3.Width=WIDTH;
                      image3.Height=HEIGHT;
                      image3.Margin= new Thickness(LocX+dw*2,LocY,0,0);
                      break;
                   case 2:
                      image3.Width=Nwidth;
                      image3.Height=Nheigth;
                      image3.Margin = new Thickness(NLocX+dw*2,NLocY,0,0);
                      image4.Width=WIDTH;
                      image4.Height=HEIGHT;
                      image4.Margin= new Thickness(LocX+dw*3,LocY,0,0);
                      break;
                   case 3:
                      image4.Width=Nwidth;
                      image4.Height=Nheigth;
                      image4.Margin = new Thickness(NLocX+dw*3,NLocY,0,0);
                      image5.Width=WIDTH;
                      image5.Height=HEIGHT;
                      image5.Margin= new Thickness(LocX+dw*4,LocY,0,0);
                      break;
                }
            }
            Uri back = new Uri(path + file[pnum], UriKind.Relative);
            BitmapImage  backmap = new BitmapImage(back );
            Backdrop.Source = backmap;
        }

        private void rightbtn_Click(object sender, RoutedEventArgs e)
        {
            Uri[] uri = new Uri[5];
            BitmapImage[] bitmap = new BitmapImage[5];
            
            if (num == 4)
            {
                if (pnum < 9)
                {
                    pnum++;
                    for (int i = 0; i < 5; i++)
                    {
                        uri[4-i] = new Uri(path + file[pnum - i], UriKind.Relative);
                        bitmap[4-i] = new BitmapImage(uri[4-i]);

                    }
                    image1.Source = bitmap[0];
                    image2.Source = bitmap[1];
                    image3.Source = bitmap[2];
                    image4.Source = bitmap[3];
                    image5.Source = bitmap[4];
                }
                image5.Width = Nwidth;
                image5.Height = Nheigth;
                image5.Margin = new Thickness(NLocX+4*dw , NLocY, 0, 0);


                image4.Width = WIDTH;
                image4.Height = HEIGHT;
                image4.Margin = new Thickness(LocX + 3*dw, LocY, 0, 0);
            }
            else
            {
                pnum++;
                num++;
                switch (num)
                {
                    case 1:
                        image1.Width = WIDTH;
                        image1.Height = HEIGHT;
                        image1.Margin = new Thickness(LocX, LocY, 0, 0);
                        image2.Width = Nwidth ;
                        image2.Height = Nheigth ;
                        image2.Margin = new Thickness(NLocX + dw, NLocY, 0, 0);
                        break;
                    case 2:
                        image2.Width = WIDTH;
                        image2.Height = HEIGHT;
                        image2.Margin = new Thickness(LocX + dw , LocY, 0, 0);
                        image3.Width = Nwidth ;
                        image3.Height = Nheigth ;
                        image3.Margin = new Thickness(NLocX + dw *2, NLocY, 0, 0);
                        break;
                    case 3:
                        image3.Width = WIDTH ;
                        image3.Height = HEIGHT;
                        image3.Margin = new Thickness(LocX + dw * 2, LocY, 0, 0);
                        image4.Width = Nwidth ;
                        image4.Height = Nheigth;
                        image4.Margin = new Thickness(NLocX + dw * 3, NLocY, 0, 0);
                        break;
                    case 4:
                        image4.Width = WIDTH;
                        image4.Height = HEIGHT;
                        image4.Margin = new Thickness(LocX + dw * 3, LocY, 0, 0);
                        image5.Width = Nwidth;
                        image5.Height = Nheigth;
                        image5.Margin = new Thickness(NLocX + dw * 4, NLocY, 0, 0);
                        break;

                  
                }
            }
            Uri back = new Uri(path + file[pnum], UriKind.Relative);
            BitmapImage backmap = new BitmapImage(back);
            Backdrop.Source = backmap;


        }

        
        
        
        
        
        
        
    }
}