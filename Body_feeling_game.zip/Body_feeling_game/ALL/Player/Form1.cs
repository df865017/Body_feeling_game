﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//--------------//
//1.骨架
//2.调用程序
//3.
using Microsoft.Kinect;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.Util;

//
using LightBuzz.Vitruvius;
using System.IO;

namespace Player
{
    public partial class Form1 : Form
    {

        private bool setup = true;
        private string exeName1 = "";
        private string exeName2 = "";


        public bool Setup2
        {
            get { return setup; }
            set { setup = value; }
        }

        //--------------------------------------------//
        //启用的Kinect设备
        private KinectSensor sensor;

        //数据缓冲存储空间
        private byte[] colorPixels;
        private DepthImagePixel[] depthPixels;
        private byte[] depthPixels4Channels;
        //1.1.8
        ColorImageFormat colorImageFormat;
        DepthImageFormat depthImageFormat;
        //1.1.7.1
        private Skeleton[] skeletonData;

        //显示图像中间结构  Kinect -> Bitmap -> Emgu CV


        //1.1.7.1
        int depthWidth, depthHeight;
        int colorWidth, colorHeight;
        //EmguCV 绘制字符串时候使用的字体
        private MCvFont font = new MCvFont(Emgu.CV.CvEnum.FONT.CV_FONT_HERSHEY_COMPLEX, 0.3, 0.3);
        //绘制骨骼使用的Image
        private Image<Bgr, Byte> skeletonImage;

        private ColorImagePoint[] colorCoordinates;

        //--------------------------------------------//
        //___________________________________________//
        //获取手势控制类
        GestureController _gestureController;


        [System.Runtime.InteropServices.DllImport("user32")]
        private static extern int mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);
        //移动鼠标 
        const int MOUSEEVENT_MOVE = 0x0001;
        //模拟鼠标左键按下 
        const int MOUSEEVENT_LEFTDOWN = 0x0002;
        //模拟鼠标左键抬起 
        const int MOUSEEVENT_LEFTUP = 0x0004;
        //模拟鼠标右键按下 
        const int MOUSEEVENT_RIGHTDOWN = 0x0008;
        //模拟鼠标右键抬起 
        const int MOUSEEVENT_RIGHTUP = 0x0010;
        //模拟鼠标中键按下 
        const int MOUSEEVENT_MIDDLEDOWN = 0x0020;
        //模拟鼠标中键抬起 
        const int MOUSEEVENT_MIDDLEUP = 0x0040;
        //标示是否采用绝对坐标 
        const int MOUSEEVENT_ABSOLUTE = 0x8000;

        [System.Runtime.InteropServices.DllImport("user32")]
        public static extern void keybd_event(
            byte bVk, //虚拟键值
            byte bScan,// 一般为0
            int dwFlags, //这里是整数类型 0 为按下，2为释放
            int dwExtraInfo //这里是整数类型 一般情况下设成为 0
            );
        const int KEY_DOWN = 0;
        const int KEY_UP = 2;

        //_____________________________________//

        public Form1()
        {
            InitializeComponent();

        }

        //骨骼数据处理事件
        private void SensorSkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            //1.1.7.1  骨骼数据处理事件
            bool received = false;

            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame != null)
                {
                    this.label1.Text = "Kinect传感器连结成功！";
                    skeletonFrame.CopySkeletonDataTo(this.skeletonData);
                    received = true;
                }
            }

            if (received)
            {

                //3.3
                //手势语骨骼代码连结起来
                foreach (Skeleton skeleton in this.skeletonData)
                {
                    if (skeleton.TrackingState == SkeletonTrackingState.Tracked)
                    {
                        _gestureController.Update(skeleton);
                    }
                }
                //重绘整个画面，冲掉原有骨骼图像
                skeletonImage.Draw(new Rectangle(0, 0, skeletonImage.Width, skeletonImage.Height), new Bgr(0.0, 0.0, 0.0), -1);

                DrawSkeletons(skeletonImage, 0);
                imageBoxSkeleton.Image = skeletonImage;
            }

        }

        //1.5.2状态栏关闭
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //停止设备
            if (null != this.sensor)
            {
                this.sensor.Stop();

            }
            this.setup = false;
            
            //this.Close();
        }
        //1.6.2 数据格式
        private void UpdateColImage(Bitmap bmp)
        {
            try
            {
                Image<Bgr, Byte> img = new Image<Bgr, Byte>(bmp);

            }
            catch { }
        }
        //1.6.3 数据格式
        private void UpdateDepImage(Bitmap bmp)
        {
            try
            {
                Image<Bgr, Byte> img = new Image<Bgr, Byte>(bmp);

            }
            catch { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //__________________//
            {
                // 1.1设备获取
                //枚举Kinect设备，并将第一个连接成功的设备做为当前设备
                //获取当前连接的Kinect设备，设备对应 KinectSensor 类
                //支持多个Kinect同时工作
                foreach (var potentialSensor in KinectSensor.KinectSensors)
                {
                    if (potentialSensor.Status == KinectStatus.Connected)
                    {
                        this.sensor = potentialSensor;
                        break;
                    }
                }


                if (null != this.sensor)
                {
                    //显示状态
                    this.label1.Text = "正在检测Kinect传感器...";
                    //1.1.8 
                    //深度图像的格式添加修改
                    colorImageFormat = ColorImageFormat.RgbResolution640x480Fps30;
                    depthImageFormat = DepthImageFormat.Resolution640x480Fps30;
                    //1.1.2初始化Kinect设置  
                    //Enable启用对应的采集数据
                    this.sensor.ColorStream.Enable(colorImageFormat);
                    this.sensor.DepthStream.Enable(depthImageFormat);
                    //1.1.7.1启用SkeletonStream
                    this.sensor.SkeletonStream.Enable();

                    //1.1.6.1 数据类型
                    this.colorPixels = new byte[this.sensor.ColorStream.FramePixelDataLength];
                    this.depthPixels = new DepthImagePixel[this.sensor.DepthStream.FramePixelDataLength];
                    this.depthPixels4Channels = new byte[this.sensor.DepthStream.FramePixelDataLength * 4];
                    //1.1.7.1
                    this.skeletonData = new Skeleton[this.sensor.SkeletonStream.FrameSkeletonArrayLength];
                    this.colorCoordinates = new ColorImagePoint[this.sensor.DepthStream.FramePixelDataLength];

                    depthWidth = this.sensor.DepthStream.FrameWidth;
                    depthHeight = this.sensor.DepthStream.FrameHeight;

                    colorWidth = this.sensor.ColorStream.FrameWidth;
                    colorHeight = this.sensor.ColorStream.FrameHeight;

                    skeletonImage = new Image<Bgr, byte>(depthWidth, depthHeight);
                    skeletonImage.Draw(new Rectangle(0, 0, depthWidth, depthHeight), new Bgr(0.0, 0.0, 0.0), -1);
                    imageBoxSkeleton.Image = skeletonImage;


                    //1.1.3添加事件处理函数

                    //姿势识别
                    _gestureController = new GestureController(GestureType.All);
                    _gestureController.GestureRecognized += GestureController_GestureRecognized;
                    //1.1.7.1添加事件处理函数
                    this.sensor.SkeletonFrameReady += this.SensorSkeletonFrameReady;

                    //1.1.5.1启动设备
                    try
                    {
                        this.sensor.Start();
                    }
                    catch (System.IO.IOException)
                    {
                        this.sensor = null;
                    }
                }
                //1.1.5.1
                if (null == this.sensor)
                {
                    MessageBox.Show("Kinect设备未准备好");
                }
                else
                {
                    this.Text = "Kinect连接成功";
                }


                //调用程序
                //--------------------//
                //Process p1 = null;
                //Process p2 = null; 


                try
                {
                    thread1();
                    //thread2();

               }
                catch (Exception ex)
                {
                    MessageBox.Show(this, ex.Message, "Error");
                }

            }
        }

        private void thread1()
        {
            this.exeName1 = "..\\kinect.exe";
            appContainer1.AppFilename = this.exeName1;
            appContainer1.Start();
        }
        /*
        private void thread2()
        {
            this.exeName2 = "..\\Skeleton.exe";
            appContainer2.AppFilename = this.exeName2;
            appContainer2.Start();
        }
        */
        //-------------------------------------//

        //1.1.7.2 绘制Skeletons骨架
        private void DrawSkeletons(Image<Bgr, Byte> img, int depthOrColor)
        {
            //绘制所有正确Tracked的骨骼
            foreach (Skeleton skeleton in this.skeletonData)
            {
                if (skeleton.TrackingState == SkeletonTrackingState.Tracked)
                {
                    DrawTrackedSkeletonJoints(img, skeleton.Joints, depthOrColor);
                }
            }
        }
        //1.1.7.2 绘制Skeletons骨架连接
        private void DrawTrackedSkeletonJoints(Image<Bgr, Byte> img, JointCollection jointCollection, int depthOrColor)
        {
            // Render Head and Shoulders
            DrawBone(img, jointCollection[JointType.Head], jointCollection[JointType.ShoulderCenter], depthOrColor);
            DrawBone(img, jointCollection[JointType.ShoulderCenter], jointCollection[JointType.ShoulderLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.ShoulderCenter], jointCollection[JointType.ShoulderRight], depthOrColor);

            // Render Left Arm
            DrawBone(img, jointCollection[JointType.ShoulderLeft], jointCollection[JointType.ElbowLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.ElbowLeft], jointCollection[JointType.WristLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.WristLeft], jointCollection[JointType.HandLeft], depthOrColor);

            // Render Right Arm
            DrawBone(img, jointCollection[JointType.ShoulderRight], jointCollection[JointType.ElbowRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.ElbowRight], jointCollection[JointType.WristRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.WristRight], jointCollection[JointType.HandRight], depthOrColor);

            // Render other bones...
            DrawBone(img, jointCollection[JointType.ShoulderCenter], jointCollection[JointType.Spine], depthOrColor);

            DrawBone(img, jointCollection[JointType.Spine], jointCollection[JointType.HipRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.KneeRight], jointCollection[JointType.HipRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.KneeRight], jointCollection[JointType.AnkleRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.FootRight], jointCollection[JointType.AnkleRight], depthOrColor);

            DrawBone(img, jointCollection[JointType.Spine], jointCollection[JointType.HipLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.KneeLeft], jointCollection[JointType.HipLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.KneeLeft], jointCollection[JointType.AnkleLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.FootLeft], jointCollection[JointType.AnkleLeft], depthOrColor);
        }
        //1.1.7.2 绘制骨头
        private void DrawBone(Image<Bgr, Byte> img, Joint jointFrom, Joint jointTo, int depthOrColor)
        {
            if (jointFrom.TrackingState == JointTrackingState.NotTracked ||
            jointTo.TrackingState == JointTrackingState.NotTracked)
            {
                return; // nothing to draw, one of the joints is not tracked
            }

            if (jointFrom.TrackingState == JointTrackingState.Inferred ||
            jointTo.TrackingState == JointTrackingState.Inferred)
            {
                DrawBoneLine(img, jointFrom.Position, jointTo.Position, 1, depthOrColor);
            }

            if (jointFrom.TrackingState == JointTrackingState.Tracked &&
            jointTo.TrackingState == JointTrackingState.Tracked)
            {
                DrawBoneLine(img, jointFrom.Position, jointTo.Position, 3, depthOrColor);
            }
        }
        //1.1.7.2 绘制连线
        private void DrawBoneLine(Image<Bgr, Byte> img, SkeletonPoint p1, SkeletonPoint p2, int lineWidth, int depthOrColor)
        {
            Point p_1, p_2;

            if (depthOrColor == 0)
            {
                p_1 = SkeletonPointToDepthScreen(p1);
                p_2 = SkeletonPointToDepthScreen(p2);
            }
            else
            {
                p_1 = SkeletonPointToColorScreen(p1);
                p_2 = SkeletonPointToColorScreen(p2);
            }

            img.Draw(new LineSegment2D(p_1, p_2), new Bgr(255, 255, 0), lineWidth);
            img.Draw(new CircleF(p_1, 5), new Bgr(0, 0, 255), -1);

            StringBuilder str = new StringBuilder();
            str.AppendFormat("({0},{1},{2})", p1.X.ToString("0.0"), p1.Y.ToString("0.0"), p1.Z.ToString("0.0"));

            img.Draw(str.ToString(), ref font, p_1, new Bgr(0, 255, 0));
            img.Draw(new CircleF(p_2, 5), new Bgr(0, 0, 255), -1);

            str.Clear();
            str.AppendFormat("({0},{1},{2})", p2.X.ToString("0.0"), p2.Y.ToString("0.0"), p2.Z.ToString("0.0"));
            img.Draw(str.ToString(), ref font, p_2, new Bgr(0, 255, 0));
        }
        //1.1.7.1 绘制点
        private Point SkeletonPointToDepthScreen(SkeletonPoint skelpoint)
        {
            DepthImagePoint depthPoint = this.sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skelpoint, depthImageFormat);
            return new Point(depthPoint.X, depthPoint.Y);
        }

        private Point SkeletonPointToColorScreen(SkeletonPoint skelpoint)
        {
            ColorImagePoint colorPoint = this.sensor.CoordinateMapper.MapSkeletonPointToColorPoint(skelpoint, colorImageFormat);
            return new Point(colorPoint.X, colorPoint.Y);
        }

        //姿势识别函数
        void GestureController_GestureRecognized(object sender, GestureEventArgs e)
        {
            Text = e.Name;

            switch (e.Type)
            {
                case GestureType.JoinedHands:
                    {
                        //变换

                        keybd_event((byte)Keys.Space, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.Space, 0, KEY_UP, 0);

                    }
                    break;
                    /*
                case GestureType.Menu:
                    {

                    }
                    break;
                    */
                case GestureType.SwipeUp:
                    {
                        //返回
                        keybd_event((byte)Keys.Down, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.Down, 0, KEY_UP, 0);
                    }
                    break;
                case GestureType.WaveLeft:
                    //翻页的效果
                    {
                        //左移
                        keybd_event((byte)Keys.Left, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.Left, 0, KEY_UP, 0);
                    }
                    break;
                case GestureType.WaveRight:
                    //翻页的效果
                    {
                        //右移
                        keybd_event((byte)Keys.Right, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.Right, 0, KEY_UP, 0);
                    }

                    break;
                case GestureType.ZoomIn:
                    {
                        keybd_event((byte)Keys.Up, 0, KEY_DOWN, 0);
                    }
                    break;

                case GestureType.ZoomOut:
                    {
                        keybd_event((byte)Keys.Up, 0, KEY_UP, 0);

                    }

                    break;
                default:
                    break;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //停止设备
            if (null != this.sensor)
            {
                this.sensor.Stop();

            }
            this.setup = false; 
            this.Close();

        }
    }
}
