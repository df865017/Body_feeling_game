﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//--------------//
using Microsoft.Kinect;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.Util;

//---BitmapData----//
using System.Runtime.InteropServices;

//5.0
using Tetris;
using LightBuzz.Vitruvius;
using System.IO;
//
using System.Threading;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace Tetris
{
    public partial class Form1 : Form
    {

        private bool setup = true;

        public bool Setup1
        {
            get { return setup; }
            set { setup = value; }
        }

        //--------------------------------------------//
        //启用的Kinect设备
        private KinectSensor sensor;

        //数据缓冲存储空间
        private byte[] colorPixels;
        private DepthImagePixel[] depthPixels;
        private byte[] depthPixels4Channels;
        //1.1.8
        ColorImageFormat colorImageFormat;
        DepthImageFormat depthImageFormat;
        //1.1.7.1
        private Skeleton[] skeletonData;

        //显示图像中间结构  Kinect -> Bitmap -> Emgu CV


        //1.1.7.1
        int depthWidth, depthHeight;
        int colorWidth, colorHeight;
        //EmguCV 绘制字符串时候使用的字体
        private MCvFont font = new MCvFont(Emgu.CV.CvEnum.FONT.CV_FONT_HERSHEY_COMPLEX, 0.3, 0.3);
        //绘制骨骼使用的Image
        private Image<Bgr, Byte> skeletonImage;

        private ColorImagePoint[] colorCoordinates;

        //--------------------------------------------//
        //___________________________________________//
        //获取手势控制类
        GestureController _gestureController;
        //1.3.2
        //手势识别的变量引入

        [System.Runtime.InteropServices.DllImport("user32")]
        private static extern int mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);
        //移动鼠标 
        const int MOUSEEVENT_MOVE = 0x0001;
        //模拟鼠标左键按下 
        const int MOUSEEVENT_LEFTDOWN = 0x0002;
        //模拟鼠标左键抬起 
        const int MOUSEEVENT_LEFTUP = 0x0004;
        //模拟鼠标右键按下 
        const int MOUSEEVENT_RIGHTDOWN = 0x0008;
        //模拟鼠标右键抬起 
        const int MOUSEEVENT_RIGHTUP = 0x0010;
        //模拟鼠标中键按下 
        const int MOUSEEVENT_MIDDLEDOWN = 0x0020;
        //模拟鼠标中键抬起 
        const int MOUSEEVENT_MIDDLEUP = 0x0040;
        //标示是否采用绝对坐标 
        const int MOUSEEVENT_ABSOLUTE = 0x8000;

        [System.Runtime.InteropServices.DllImport("user32")]
        public static extern void keybd_event(
            byte bVk, //虚拟键值
            byte bScan,// 一般为0
            int dwFlags, //这里是整数类型 0 为按下，2为释放
            int dwExtraInfo //这里是整数类型 一般情况下设成为 0
            );
        const int KEY_DOWN = 0;
        const int KEY_UP = 2;

        //2.0.1
        private bool state = true;
        public int speed;//速度
        private int score;//分数
        private int lines;//行数
        //2.0.2
        private Shape nextShape;//下次出现图形
        private Body mainBody = new Body();
        private Random rndShape = new Random();//定义随机数
        private GAME_STATUS gameStatus;//游戏状态
        //列举游戏状态
        enum GAME_STATUS { GAME_STOP, GAME_RUN, GAME_OVER };

        //_____________________________________//

        public Form1()
        {
            //1.1骨架的绘制
            InitializeComponent();
            //1.2方块的图像
            Shape.InitTetrisDefine();
        }

        //骨骼数据处理事件
        private void SensorSkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            //1.1.7.1  骨骼数据处理事件
            bool received = false;

            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame != null)
                {
                    this.label1.Text = "Kinect传感器连结成功！";
                    skeletonFrame.CopySkeletonDataTo(this.skeletonData);
                    received = true;
                }
            }

            if (received)
            {

                //3.3
                //手势语骨骼代码连结起来
                foreach (Skeleton skeleton in this.skeletonData)
                {
                    if (skeleton.TrackingState == SkeletonTrackingState.Tracked)
                    {
                        _gestureController.Update(skeleton);
                    }
                }
                //重绘整个画面，冲掉原有骨骼图像
                skeletonImage.Draw(new Rectangle(0, 0, skeletonImage.Width, skeletonImage.Height), new Bgr(0.0, 0.0, 0.0), -1);

                DrawSkeletons(skeletonImage, 0);
                imageBoxSkeleton.Image = skeletonImage;
            }

        }

        //1.5.2状态栏关闭
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //停止设备
            if (null != this.sensor)
            {
                this.sensor.Stop();
            }
            this.setup = false;
        }
        //1.6.2 数据格式
        private void UpdateColImage(Bitmap bmp)
        {
            try
            {
                Image<Bgr, Byte> img = new Image<Bgr, Byte>(bmp);

            }
            catch { }
        }
        //1.6.3 数据格式
        private void UpdateDepImage(Bitmap bmp)
        {
            try
            {
                Image<Bgr, Byte> img = new Image<Bgr, Byte>(bmp);
                //imageBoxDepth.Image = img;
                //Image<Gray, Byte> grayImg = img.Convert<Gray, Byte>();
                //imageBoxDepth.Image = grayImg;
            }
            catch { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            {
                // 1.1设备获取
                //枚举Kinect设备，并将第一个连接成功的设备做为当前设备
                //获取当前连接的Kinect设备，设备对应 KinectSensor 类
                //支持多个Kinect同时工作
                foreach (var potentialSensor in KinectSensor.KinectSensors)
                {
                    if (potentialSensor.Status == KinectStatus.Connected)
                    {
                        this.sensor = potentialSensor;
                        break;
                    }
                }


                if (null != this.sensor)
                {
                    //显示状态
                    this.label1.Text = "正在检测Kinect传感器...";
                    //1.1.8 
                    //深度图像的格式添加修改
                    colorImageFormat = ColorImageFormat.RgbResolution640x480Fps30;
                    depthImageFormat = DepthImageFormat.Resolution640x480Fps30;
                    //1.1.2初始化Kinect设置  
                    //Enable启用对应的采集数据
                    this.sensor.ColorStream.Enable(colorImageFormat);
                    this.sensor.DepthStream.Enable(depthImageFormat);
                    //1.1.7.1启用SkeletonStream
                    this.sensor.SkeletonStream.Enable();

                    //1.1.6.1 数据类型
                    this.colorPixels = new byte[this.sensor.ColorStream.FramePixelDataLength];
                    this.depthPixels = new DepthImagePixel[this.sensor.DepthStream.FramePixelDataLength];
                    this.depthPixels4Channels = new byte[this.sensor.DepthStream.FramePixelDataLength * 4];
                    //1.1.7.1
                    this.skeletonData = new Skeleton[this.sensor.SkeletonStream.FrameSkeletonArrayLength];
                    this.colorCoordinates = new ColorImagePoint[this.sensor.DepthStream.FramePixelDataLength];

                    depthWidth = this.sensor.DepthStream.FrameWidth;
                    depthHeight = this.sensor.DepthStream.FrameHeight;

                    colorWidth = this.sensor.ColorStream.FrameWidth;
                    colorHeight = this.sensor.ColorStream.FrameHeight;

                    skeletonImage = new Image<Bgr, byte>(depthWidth, depthHeight);
                    skeletonImage.Draw(new Rectangle(0, 0, depthWidth, depthHeight), new Bgr(0.0, 0.0, 0.0), -1);
                    imageBoxSkeleton.Image = skeletonImage;


                    //1.1.3添加事件处理函数

                    //姿势识别
                    _gestureController = new GestureController(GestureType.All);
                    _gestureController.GestureRecognized += GestureController_GestureRecognized;
                    //1.1.7.1添加事件处理函数
                    this.sensor.SkeletonFrameReady += this.SensorSkeletonFrameReady;

                    //1.1.5.1启动设备
                    try
                    {
                        this.sensor.Start();
                    }
                    catch (System.IO.IOException)
                    {
                        this.sensor = null;
                    }
                }
                //1.1.5.1
                if (null == this.sensor)
                {
                    MessageBox.Show("Kinect设备未准备好");
                }
                else
                {
                    this.Text = "Kinect连接成功";
                }

            }
        }
        //-------------------------------------//

        //1.1.7.2 绘制Skeletons骨架
        private void DrawSkeletons(Image<Bgr, Byte> img, int depthOrColor)
        {
            //绘制所有正确Tracked的骨骼
            foreach (Skeleton skeleton in this.skeletonData)
            {
                if (skeleton.TrackingState == SkeletonTrackingState.Tracked)
                {
                    DrawTrackedSkeletonJoints(img, skeleton.Joints, depthOrColor);
                }
            }
        }
        //1.1.7.2 绘制Skeletons骨架连接
        private void DrawTrackedSkeletonJoints(Image<Bgr, Byte> img, JointCollection jointCollection, int depthOrColor)
        {
            // Render Head and Shoulders
            DrawBone(img, jointCollection[JointType.Head], jointCollection[JointType.ShoulderCenter], depthOrColor);
            DrawBone(img, jointCollection[JointType.ShoulderCenter], jointCollection[JointType.ShoulderLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.ShoulderCenter], jointCollection[JointType.ShoulderRight], depthOrColor);

            // Render Left Arm
            DrawBone(img, jointCollection[JointType.ShoulderLeft], jointCollection[JointType.ElbowLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.ElbowLeft], jointCollection[JointType.WristLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.WristLeft], jointCollection[JointType.HandLeft], depthOrColor);

            // Render Right Arm
            DrawBone(img, jointCollection[JointType.ShoulderRight], jointCollection[JointType.ElbowRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.ElbowRight], jointCollection[JointType.WristRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.WristRight], jointCollection[JointType.HandRight], depthOrColor);

            // Render other bones...
            DrawBone(img, jointCollection[JointType.ShoulderCenter], jointCollection[JointType.Spine], depthOrColor);

            DrawBone(img, jointCollection[JointType.Spine], jointCollection[JointType.HipRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.KneeRight], jointCollection[JointType.HipRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.KneeRight], jointCollection[JointType.AnkleRight], depthOrColor);
            DrawBone(img, jointCollection[JointType.FootRight], jointCollection[JointType.AnkleRight], depthOrColor);

            DrawBone(img, jointCollection[JointType.Spine], jointCollection[JointType.HipLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.KneeLeft], jointCollection[JointType.HipLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.KneeLeft], jointCollection[JointType.AnkleLeft], depthOrColor);
            DrawBone(img, jointCollection[JointType.FootLeft], jointCollection[JointType.AnkleLeft], depthOrColor);
        }
        //1.1.7.2 绘制骨头
        private void DrawBone(Image<Bgr, Byte> img, Joint jointFrom, Joint jointTo, int depthOrColor)
        {
            if (jointFrom.TrackingState == JointTrackingState.NotTracked ||
            jointTo.TrackingState == JointTrackingState.NotTracked)
            {
                return; // nothing to draw, one of the joints is not tracked
            }

            if (jointFrom.TrackingState == JointTrackingState.Inferred ||
            jointTo.TrackingState == JointTrackingState.Inferred)
            {
                DrawBoneLine(img, jointFrom.Position, jointTo.Position, 1, depthOrColor);
            }

            if (jointFrom.TrackingState == JointTrackingState.Tracked &&
            jointTo.TrackingState == JointTrackingState.Tracked)
            {
                DrawBoneLine(img, jointFrom.Position, jointTo.Position, 3, depthOrColor);
            }
        }
        //1.1.7.2 绘制连线
        private void DrawBoneLine(Image<Bgr, Byte> img, SkeletonPoint p1, SkeletonPoint p2, int lineWidth, int depthOrColor)
        {
            Point p_1, p_2;

            if (depthOrColor == 0)
            {
                p_1 = SkeletonPointToDepthScreen(p1);
                p_2 = SkeletonPointToDepthScreen(p2);
            }
            else
            {
                p_1 = SkeletonPointToColorScreen(p1);
                p_2 = SkeletonPointToColorScreen(p2);
            }

            img.Draw(new LineSegment2D(p_1, p_2), new Bgr(255, 255, 0), lineWidth);
            img.Draw(new CircleF(p_1, 5), new Bgr(0, 0, 255), -1);

            StringBuilder str = new StringBuilder();
            str.AppendFormat("({0},{1},{2})", p1.X.ToString("0.0"), p1.Y.ToString("0.0"), p1.Z.ToString("0.0"));

            img.Draw(str.ToString(), ref font, p_1, new Bgr(0, 255, 0));
            img.Draw(new CircleF(p_2, 5), new Bgr(0, 0, 255), -1);

            str.Clear();
            str.AppendFormat("({0},{1},{2})", p2.X.ToString("0.0"), p2.Y.ToString("0.0"), p2.Z.ToString("0.0"));
            img.Draw(str.ToString(), ref font, p_2, new Bgr(0, 255, 0));
        }
        //1.1.7.1 绘制点
        private Point SkeletonPointToDepthScreen(SkeletonPoint skelpoint)
        {
            DepthImagePoint depthPoint = this.sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skelpoint, depthImageFormat);
            return new Point(depthPoint.X, depthPoint.Y);
        }

        private Point SkeletonPointToColorScreen(SkeletonPoint skelpoint)
        {
            ColorImagePoint colorPoint = this.sensor.CoordinateMapper.MapSkeletonPointToColorPoint(skelpoint, colorImageFormat);
            return new Point(colorPoint.X, colorPoint.Y);
        }

        //1.3.2
        //姿势识别函数
        //事件处理函数（识别成功）
        void GestureController_GestureRecognized(object sender, GestureEventArgs e)
        {
            Text = e.Name;

            switch (e.Type)
            {
                case GestureType.JoinedHands:
                    {
                        //变换

                        keybd_event((byte)Keys.Up, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.Up, 0, KEY_UP, 0);

                    }
                    break;
                /*
            case GestureType.Menu:
                {

                }
                     
                break;
                 **/
                // case GestureType.SwipeDown:
                //     break;
                // case GestureType.SwipeLeft:
                //     //鼠标移动效果
                //     /*
                //     {
                //         mouse_event(MOUSEEVENT_MOVE, -10, 0, 0, 0);
                //     }
                //      * */

                //     break;
                //case GestureType.SwipeRight:
                //    //鼠标移动效果
                //    /*
                //    {
                //        mouse_event(MOUSEEVENT_MOVE, 10, 0, 0, 0);
                //    }
                //     */

                //    break;
                case GestureType.SwipeUp:
                    {
                        //加速
                        keybd_event((byte)Keys.Down, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.Down, 0, KEY_UP, 0);
                    }
                    break;
                case GestureType.WaveLeft:
                    //翻页的效果
                    {
                        //左移
                        keybd_event((byte)Keys.Left, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.Left, 0, KEY_UP, 0);
                    }
                    break;
                case GestureType.WaveRight:
                    //翻页的效果
                    {
                        //右移
                        keybd_event((byte)Keys.Right, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.Right, 0, KEY_UP, 0);
                    }

                    break;
                case GestureType.ZoomIn:
                    {
                        //ZoomIn  ctrl+s
                        //put you hands between hip and shoulder
                        //open quick
                        keybd_event((byte)Keys.LControlKey, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.S, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.S, 0, KEY_UP, 0);
                        keybd_event((byte)Keys.LControlKey, 0, KEY_UP, 0);

                    }
                    break;

                case GestureType.ZoomOut:
                    {
                        //ZoomOut ctrl+t 
                        keybd_event((byte)Keys.LControlKey, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.T, 0, KEY_DOWN, 0);
                        keybd_event((byte)Keys.T, 0, KEY_UP, 0);
                        keybd_event((byte)Keys.LControlKey, 0, KEY_UP, 0);

                    }

                    break;
                default:
                    break;
            }
        }

        ///2.0 开始菜单事件监听器
        ///
        private void startMenu_Click(object sender, EventArgs e)
        {
            StartGame();
        }

        ///2.0游戏开始
        public void StartGame()
        {


            //2.1 body区域
            //2.2 绘制屏幕
            //

            if (state)
            {
                comboBox1.Enabled = false;  //1.2速度框
                //初始化
                score = 0;
                speed = 0;
                lines = 0;

                ChangeLines(0);            //得分
                timer.Interval = SpeedToTime(speed);  // 方块下落速度控制方法
                timer.Enabled = true;     // 计时器
                startMenu.Enabled = false;
                stopMenu.Enabled = true;
                mainBody.Reset();         // 方块清除
                GetNextShape(true);      // 获取下次进入的方块
                DrawScreen();
                gameStatus = GAME_STATUS.GAME_RUN;
            }
            else
            {
                comboBox1.Enabled = false;
                timer.Interval = SpeedToTime(speed); //修改速度
                timer.Enabled = true;
                startMenu.Enabled = false;
                stopMenu.Enabled = true;
                // mainBody.Reset();
                // GetNextShape(false);
                DrawScreen();
                gameStatus = GAME_STATUS.GAME_RUN;

            }
        }
        //2.1.1
        public void ChangeLines(int count)
        {
            switch (count)
            {
                case 1:
                    score += 100;
                    break;
                case 2:
                    score += 200;
                    break;
                case 3:
                    score += 400;
                    break;
                case 4:
                    score += 800;
                    break;
                default:
                    break;
            }
            lines += count;
            speed = Convert.ToInt32(comboBox1.Text);
            //speed++;
            timer.Interval = SpeedToTime(speed);
            scoreLabel.Text = score.ToString();
            linesLabel.Text = lines.ToString();
        }
        //2.1.2
        /// 方块下落速度控制方法
        public int SpeedToTime(int nSpeed)
        {
            switch (nSpeed)
            {
                case 0:
                    return (1000);
                case 1:
                    return (900);
                case 2:
                    return (800);
                case 3:
                    return (700);
                case 4:
                    return (600);
                case 5:
                    return (500);
                case 6:
                    return (400);
                case 7:
                    return (300);
                case 8:
                    return (200);
                case 9:
                    return (150);
                default:
                    return (150);
            }
        }
        //2.1.3
        /// 获取下次降落的方块
        /// 
        public bool GetNextShape(bool initGame)
        {
            int shapeCount = 7;
            if (initGame)
            {
                int indexShape = rndShape.Next(shapeCount);
                nextShape = new Shape(indexShape);
            }

            bool ret = mainBody.SetNextShape(nextShape);
            int indNextShape = rndShape.Next(shapeCount);
            nextShape = new Shape(indNextShape);
            return ret;
        }


        /// <summary>
        /// 2.2.1绘制窗体屏幕的方法
        /// </summary>
        public void DrawScreen()
        {
            //判断游戏状态
            if (gameStatus == GAME_STATUS.GAME_RUN || gameStatus == GAME_STATUS.GAME_OVER)
            {
                ReDrawNextShape();

                Graphics grMain = screenPanel.CreateGraphics();
                grMain.FillRectangle(new SolidBrush(Color.White), 0, 0, screenPanel.Width, screenPanel.Height);
                mainBody.Draw(grMain);
            }
            if (gameStatus == GAME_STATUS.GAME_STOP || gameStatus == GAME_STATUS.GAME_OVER)
            {
                Graphics grMain = screenPanel.CreateGraphics();
                string logo = "体 感 游 戏 之 俄 罗 斯 方 块";

                DrawText(logo, grMain, new Point(10, (int)(screenPanel.Height * 0.28)), 20);
            }
            if (gameStatus == GAME_STATUS.GAME_OVER)
            {
                Graphics grMain = screenPanel.CreateGraphics();
                string logo = " 游 戏 结 束  ";

                DrawText(logo, grMain, new Point(20, (int)(screenPanel.Height * 0.42)), 15);
            }
        }
        //2.2.1.1
        /// 在窗体上写文字的方法
        /// 
        public void DrawText(string text, Graphics g, Point pt, int font)
        {
            Font drawFont = new Font("Courier new", font, FontStyle.Bold);

            for (int i = 0; i < text.Length; i++)
            {
                int corIndex = i;
                if (i >= 7)
                    corIndex = i % 7;
                SolidBrush drawBrush = new SolidBrush(Block.GetColor(corIndex));
                string drawText = new String(' ', i);
                drawText += text.Substring(i, 1);
                g.DrawString(drawText, drawFont, drawBrush, pt);
            }
        }
        /// 2.2.2重绘将要下落的图形界面
        public void ReDrawNextShape()
        {
            Graphics grNext = nextPanel.CreateGraphics();
            grNext.FillRectangle(new SolidBrush(Color.White), 0, 0, nextPanel.Width, nextPanel.Height);
            nextShape.Draw(grNext, nextPanel.Size);

            Graphics grMain = screenPanel.CreateGraphics();
            mainBody.DrawNextShape(grMain);
        }

        //3.0游戏暂停

        private void stopMenu_Click(object sender, EventArgs e)
        {
            StopGame();
        }
        //3.0停止游戏的方法
        public void StopGame()
        {
            //
            //
            state = false;
            comboBox1.Enabled = true;
            startMenu.Enabled = true;
            stopMenu.Enabled = false;
            gameStatus = GAME_STATUS.GAME_STOP;
            //GetNextShape(false);
            //DrawScreen();
        }
        //4.0游戏结束

        private void exitMenu_Click(object sender, EventArgs e)
        {
            GameOver();
        }
        /// 游戏结束的处理方法
        public void GameOver()
        {
            state = true;

            gameStatus = GAME_STATUS.GAME_OVER;
            timer.Enabled = false;
            startMenu.Enabled = true;
            stopMenu.Enabled = false;
            comboBox1.Enabled = true;
            DrawScreen();
        }
        //5.0 //绘制屏幕细节
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            DrawScreen();
            try
            {
                pictureBox1.Image = Image.FromFile(Application.StartupPath + "\\image\\instruction.jpg");
            }
            catch (FileNotFoundException ef)
            {
                Console.WriteLine("文件未找到：" + ef.StackTrace);

            }
        }

        //6.0
        /// 计时器事件监听器
        private void OnTimer(object sender, System.EventArgs e)
        {
            if (gameStatus == GAME_STATUS.GAME_RUN)
            {
                Graphics grMain = screenPanel.CreateGraphics();
                if (mainBody.MoveShape(grMain, Body.MOVE_TYPE.MOVE_DOWN))
                {
                    DisposeShapeDown();
                }
            }
        }
        ///6.1.1 方块下落的处理方法
        public void DisposeShapeDown()
        {
            int count = mainBody.ClearLines();
            if (GetNextShape())  //游戏结束
            {
                GameOver();
            }

            if (count > 0)
            {
                ChangeLines(count);   //得分
                DrawScreen();
            }
            else
            {
                ReDrawNextShape();
            }
        }
        ///6.1.2 获得下一个方块的构造方法
        /// 
        public bool GetNextShape()
        {
            return GetNextShape(false);
        }
        ///7.1 键盘事件
        ///给窗体添加键盘事件监听器
        /// 
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            int key = e.KeyValue;
            bool ret;
            Graphics grMain = screenPanel.CreateGraphics();
            if (gameStatus == GAME_STATUS.GAME_RUN)
            {
                switch (key)
                {
                    case 38:	//	up
                        ret = mainBody.MoveShape(grMain, Body.MOVE_TYPE.MOVE_ROATE);
                        break;
                    case 37:	//	left
                        ret = mainBody.MoveShape(grMain, Body.MOVE_TYPE.MOVE_LEFT);
                        break;
                    case 39:	//	right
                        ret = mainBody.MoveShape(grMain, Body.MOVE_TYPE.MOVE_RIGHT);
                        break;
                    case 40:	//	fall down
                        ret = mainBody.MoveShape(grMain, Body.MOVE_TYPE.MOVE_FALL);
                        break;
                    default:
                        ret = false;
                        break;
                }
                if (ret && key == 40)
                {
                    DisposeShapeDown();
                }
            }
        }

        //返回主界面

        private void END_Click(object sender, EventArgs e)
        {

            this.Close();
            this.setup = false;
        }


    }
}
