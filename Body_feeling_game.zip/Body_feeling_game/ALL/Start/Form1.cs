﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//
using Tetris;
using Player;
using Microsoft.Samples.Kinect.BackgroundRemovalBasics;

namespace Start
{
    public partial class Form1 : Form
    {
        //声明对象
        private Tetris.Form1 tetris;
        private Player.Form1 player;
        private Microsoft.Samples.Kinect.BackgroundRemovalBasics.MainWindow BRB;
 
        public Form1()
        {
            InitializeComponent();
            tetris = new Tetris.Form1();
            player = new Player.Form1();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //隐藏当前form
            if(this.Enabled)
            this.Hide();
            //打开对应的项目
            if (!tetris.Setup1) 
            tetris = new Tetris.Form1();
            tetris.Show();
            //启动计时器
            if (!this.timer1.Enabled)
                this.timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //隐藏当前form
            if (this.Enabled)
            this.Hide();
            //打开对应的项目
            if (!player.Setup2)
             player = new Player.Form1();
             player.Show();
            //启动计时器
            if (!this.timer1.Enabled)
                this.timer1.Start();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.Enabled)
            {
                this.Hide();
            }
            //调用WPF窗口
           // if(!BRB.Setup3) 
            BRB= new Microsoft.Samples.Kinect.BackgroundRemovalBasics.MainWindow();
            BRB.Show();
               
            //启动计时器
            if (!this.timer1.Enabled)
                this.timer1.Start();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void OnTime(object sender, EventArgs e)
        {
            if (!tetris.Setup1) //窗口关闭
            {
                this.Show();
            }
            else if (!player.Setup2)
            {
                this.Show();           
            }
            /*else if (!BRB.Setup3)
            {
               this.Show();
            }
            */
            
        }


    }
}
